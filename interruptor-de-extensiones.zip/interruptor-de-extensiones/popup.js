const listEl = document.getElementById('list');
const emptyEl = document.getElementById('empty');
const searchEl = document.getElementById('search');
const statusEl = document.getElementById('status');
const disableAllBtn = document.getElementById('disableAll');
const restoreBtn = document.getElementById('restore');

const SAVED_KEY = 'previouslyEnabled';
let extensions = [];

// Mientras desactivamos/restauramos varias extensiones seguidas, cada
// cambio dispara los listeners de chrome.management y cada uno llamaría a
// load() por su cuenta. Con esto evitamos esa cadena de recargas redundantes
// mientras la propia función en curso ya se encarga de refrescar al final.
let suppressAutoReload = false;

function say(text) {
  statusEl.textContent = text;
}

async function load() {
  if (suppressAutoReload) return;
  try {
    const all = await chrome.management.getAll();
    extensions = all
      .filter((e) => e.type === 'extension' && e.id !== chrome.runtime.id)
      .sort((a, b) => a.name.localeCompare(b.name, 'es', { sensitivity: 'base' }));
    render();
    await refreshRestoreButton();
  } catch (err) {
    say('No se pudo leer la lista de extensiones: ' + err.message);
  }
}

function iconFor(ext) {
  if (!ext.icons || !ext.icons.length) return null;
  const best = ext.icons.reduce((a, b) => (b.size > a.size ? b : a));
  return best.url;
}

function render() {
  const q = searchEl.value.trim().toLowerCase();
  listEl.textContent = '';
  const shown = extensions.filter((e) => e.name.toLowerCase().includes(q));
  emptyEl.hidden = shown.length > 0;

  for (const ext of shown) {
    const li = document.createElement('li');
    if (!ext.enabled) li.classList.add('off');

    const url = iconFor(ext);
    if (url) {
      const img = document.createElement('img');
      img.src = url;
      img.alt = '';
      img.addEventListener('error', () => img.remove());
      li.appendChild(img);
    }

    const info = document.createElement('div');
    info.className = 'info';
    const name = document.createElement('div');
    name.className = 'name';
    name.textContent = ext.name;
    name.title = ext.name;
    info.appendChild(name);

    const locked = ext.mayDisable === false;
    if (locked) {
      const note = document.createElement('div');
      note.className = 'note';
      note.textContent = 'Administrada por tu organización: no se puede cambiar';
      info.appendChild(note);
    }
    li.appendChild(info);

    const cfg = document.createElement('button');
    cfg.type = 'button';
    cfg.className = 'cfg';
    cfg.textContent = 'Ajustes';
    cfg.title = 'Abrir la página de esta extensión en chrome://extensions';
    cfg.addEventListener('click', () => openSettings(ext));
    li.appendChild(cfg);

    const label = document.createElement('label');
    label.className = 'switch';
    const input = document.createElement('input');
    input.type = 'checkbox';
    input.checked = ext.enabled;
    input.disabled = locked;
    input.setAttribute('aria-label', (ext.enabled ? 'Desactivar ' : 'Activar ') + ext.name);
    input.addEventListener('change', () => toggle(ext, input));
    const track = document.createElement('span');
    label.append(input, track);
    li.appendChild(label);

    listEl.appendChild(li);
  }
}

async function toggle(ext, input) {
  const wanted = input.checked;
  try {
    await chrome.management.setEnabled(ext.id, wanted);
  } catch (err) {
    say('No se pudo cambiar «' + ext.name + '»: ' + err.message);
  }
  // Comprobar el estado real, no fiarse solo de que no haya error
  try {
    const real = await chrome.management.get(ext.id);
    ext.enabled = real.enabled;
    if (real.enabled === wanted) {
      say((wanted ? 'Activada: ' : 'Desactivada: ') + ext.name);
    } else {
      say('«' + ext.name + '» sigue ' + (real.enabled ? 'activada' : 'desactivada') + '. Usa «Ajustes» para cambiarla a mano.');
    }
  } catch (err) {
    say('No se pudo comprobar «' + ext.name + '»: ' + err.message);
  }
  render();
}

function openSettings(ext) {
  chrome.tabs.create({ url: 'chrome://extensions/?id=' + ext.id });
}

async function disableAll() {
  const targets = extensions.filter((e) => e.enabled && e.mayDisable !== false);
  if (!targets.length) {
    say('No hay extensiones que se puedan desactivar.');
    return;
  }

  // Fusionar con lo que ya hubiera guardado, en vez de machacarlo: si el
  // usuario ya había reactivado alguna a mano y vuelve a pulsar este botón,
  // no queremos perder el resto de la lista anterior.
  const data = await chrome.storage.local.get(SAVED_KEY);
  const previous = data[SAVED_KEY] || [];
  const merged = Array.from(new Set([...previous, ...targets.map((e) => e.id)]));
  await chrome.storage.local.set({ [SAVED_KEY]: merged });

  const failedNames = [];
  suppressAutoReload = true;
  for (const ext of targets) {
    try {
      await chrome.management.setEnabled(ext.id, false);
      ext.enabled = false;
    } catch (err) {
      failedNames.push(ext.name);
    }
  }
  suppressAutoReload = false;

  say(
    failedNames.length
      ? 'Desactivadas ' + (targets.length - failedNames.length) + '; no se pudieron cambiar: ' + failedNames.join(', ') + '.'
      : 'Desactivadas ' + targets.length + ' extensiones.'
  );
  render();
  await refreshRestoreButton();
}

async function restore() {
  const data = await chrome.storage.local.get(SAVED_KEY);
  const ids = data[SAVED_KEY] || [];
  const failedNames = [];
  const stillFailed = [];

  suppressAutoReload = true;
  for (const id of ids) {
    const ext = extensions.find((e) => e.id === id);
    try {
      await chrome.management.setEnabled(id, true);
      if (ext) ext.enabled = true;
    } catch (err) {
      failedNames.push(ext ? ext.name : id);
      stillFailed.push(id);
    }
  }
  suppressAutoReload = false;

  // Solo se borran de la lista guardada las que sí se restauraron; las que
  // fallaron (p. ej. ya no existen, o no se pudieron activar) se mantienen
  // para poder reintentarlo más tarde.
  if (stillFailed.length) {
    await chrome.storage.local.set({ [SAVED_KEY]: stillFailed });
  } else {
    await chrome.storage.local.remove(SAVED_KEY);
  }

  say(
    failedNames.length
      ? 'Restauradas ' + (ids.length - failedNames.length) + '; no se pudieron activar: ' + failedNames.join(', ') + '.'
      : 'Restauradas ' + ids.length + ' extensiones.'
  );
  render();
  await refreshRestoreButton();
}

async function refreshRestoreButton() {
  const data = await chrome.storage.local.get(SAVED_KEY);
  restoreBtn.disabled = !(data[SAVED_KEY] && data[SAVED_KEY].length);
}

searchEl.addEventListener('input', render);
disableAllBtn.addEventListener('click', disableAll);
restoreBtn.addEventListener('click', restore);

// Mantener el panel sincronizado si cambian desde chrome://extensions
chrome.management.onEnabled.addListener(load);
chrome.management.onDisabled.addListener(load);
chrome.management.onInstalled.addListener(load);
chrome.management.onUninstalled.addListener(load);

load();
